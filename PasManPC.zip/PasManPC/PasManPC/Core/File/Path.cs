﻿using System;
using System.IO;

namespace PasManPC.Core._File
{
    public class FilePath
    {
        private string _path;

        public FilePath(string str)
        {
            Path = str;
        }

        public string Path
        {
            get => _path;
            set => _path = value;
        }
        public string Extention
        {
            get => System.IO.Path.GetExtension(Path);
            set => System.IO.Path.ChangeExtension(Path, value);
        }
        public string FileName => System.IO.Path.GetFileName(Path);
        public string DirectoryName => System.IO.Path.GetDirectoryName(Path);

        public static FilePath operator +(FilePath lhs, FilePath rhs) => new FilePath(System.IO.Path.Combine(lhs.Path, rhs.Path));
        public static FilePath operator +(FilePath lhs, string rhs) => new FilePath(System.IO.Path.Combine(lhs.Path, rhs));
    }
}
